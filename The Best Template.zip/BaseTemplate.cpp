
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;
vector<int>v;
ifstream fin("");
ofstream fout("");
int main()
{
    int n;
    fin >> n;
    return 0;
}
//=^..^=